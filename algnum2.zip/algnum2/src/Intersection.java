
public class Intersection {
    private int id;
    
    public Intersection(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

   

}